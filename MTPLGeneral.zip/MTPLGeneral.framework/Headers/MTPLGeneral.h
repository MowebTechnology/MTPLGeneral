//
//  MTPLGeneral.h
//  MTPLGeneral
//
//  Created by Ankit Patel on 06/02/20.
//  Copyright © 2020 Moweb. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MTPLGeneral.
FOUNDATION_EXPORT double MTPLGeneralVersionNumber;

//! Project version string for MTPLGeneral.
FOUNDATION_EXPORT const unsigned char MTPLGeneralVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MTPLGeneral/PublicHeader.h>


